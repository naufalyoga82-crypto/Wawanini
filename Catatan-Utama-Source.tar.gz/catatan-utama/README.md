# Catatan Utama

Aplikasi catatan Android mandiri dengan widget layar utama yang dapat digulir. Proyek ini terpisah dari TARDIGRADE dan tidak memiliki dependensi ke aplikasi tersebut.

## Fitur

- Simpan beberapa catatan secara lokal di penyimpanan privat aplikasi.
- Pilih satu catatan untuk ditampilkan di widget.
- Baca isi catatan yang panjang langsung dari layar utama.
- Widget menggunakan `ListView` milik Android (`RemoteViews` collection widget), bukan `TextView` pendek yang terpotong.
- Widget dapat diubah ukuran horizontal dan vertikal.
- Edit atau hapus catatan melalui aplikasi.
- Impor teks dari aplikasi lain melalui menu **Bagikan** jika aplikasi sumber mendukung berbagi teks.
- Tidak meminta izin internet dan tidak mengirim catatan ke server.

## Memasang widget

1. Pasang APK dan buka Catatan Utama.
2. Buat catatan, lalu tekan **Simpan Catatan**.
3. Tekan **Tampilkan di Widget** pada catatan yang ingin dibaca.
4. Kembali ke layar utama Android.
5. Tekan lama area kosong layar utama, buka **Widget**, lalu pilih **Catatan Utama**.
6. Letakkan widget dan perbesar ukurannya agar area baca lebih tinggi.
7. Geser jari ke atas/bawah pada isi catatan di widget untuk membaca bagian selanjutnya.

Ketuk bagian judul widget untuk membuka catatan yang sedang ditampilkan dan mengeditnya. Untuk memindahkan isi dari aplikasi catatan lama, pilih teks lalu gunakan **Bagikan > Catatan Utama** bila tersedia; jika tidak tersedia, salin-tempel teks ke editor.

## Build APK

### Android Studio

1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions

Proyek sudah menyertakan workflow `.github/workflows/build-apk.yml`. Setelah seluruh isi folder proyek diunggah ke repository GitHub baru pada branch `main`, workflow akan membangun APK debug. Unduh artefak `CATATAN-UTAMA-DEBUG-APK` dari halaman Actions pada run yang berhasil.

## Kompatibilitas dan catatan pengujian

- Minimum Android: Android 8.0 (API 26).
- Target/compile SDK proyek: API 35.
- Widget collection Android mendukung gulir vertikal melalui `ListView`. Namun, perilaku sentuhan tetap perlu diuji pada launcher perangkat yang digunakan karena beberapa launcher OEM dapat menangani gesture widget secara berbeda.
- Jika gesture gulir tidak diteruskan launcher, coba tambahkan widget pada launcher bawaan perangkat dan berikan area widget yang lebih tinggi.

## Struktur

- `app/src/main/java/id/yoga/catatanutama/MainActivity.kt`: editor dan daftar catatan.
- `app/src/main/java/id/yoga/catatanutama/data/NoteRepository.kt`: penyimpanan lokal.
- `app/src/main/java/id/yoga/catatanutama/widget/NoteWidgetProvider.kt`: pembaruan widget.
- `app/src/main/java/id/yoga/catatanutama/widget/NoteWidgetService.kt`: data paragraf yang dapat digulir.
