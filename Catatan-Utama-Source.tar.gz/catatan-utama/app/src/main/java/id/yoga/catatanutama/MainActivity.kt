package id.yoga.catatanutama

import android.app.Activity
import android.content.Intent
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import id.yoga.catatanutama.data.Note
import id.yoga.catatanutama.data.NoteRepository
import id.yoga.catatanutama.widget.NoteWidgetProvider
import java.text.DateFormat
import java.util.Date
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var titleInput: EditText
    private lateinit var contentInput: EditText
    private lateinit var notesList: LinearLayout
    private lateinit var selectedLabel: TextView
    private var editingId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        val sharedNote = importSharedText(intent)
        val requestedId = intent.getStringExtra(EXTRA_NOTE_ID)
        val initial = sharedNote
            ?: requestedId?.let { NoteRepository.find(this, it) }
            ?: NoteRepository.active(this)
        if (initial != null) loadNote(initial) else startNewNote()
        renderNotesList()
        if (sharedNote != null) {
            NoteWidgetProvider.refreshAll(this)
            Toast.makeText(this, "Teks berhasil diimpor sebagai catatan baru", Toast.LENGTH_LONG).show()
        }
    }

    private fun importSharedText(source: Intent): Note? {
        if (source.action != Intent.ACTION_SEND || source.type != "text/plain") return null
        val sharedText = source.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotBlank() } ?: return null
        val now = System.currentTimeMillis()
        val title = source.getStringExtra(Intent.EXTRA_SUBJECT)?.trim()
            ?.takeIf { it.isNotBlank() } ?: "Catatan dibagikan"
        val note = Note(
            id = UUID.randomUUID().toString(),
            title = title,
            content = sharedText,
            createdAt = now,
            updatedAt = now,
        )
        NoteRepository.save(this, note)
        NoteRepository.setActive(this, note.id)
        return note
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(15, 16, 22))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }

        content.addView(label("CATATAN UTAMA", 25f, Color.WHITE, true))
        content.addView(label("Tulis di sini. Baca langsung dari layar utama.", 14f, 0xFFB8B8C5.toInt()).apply {
            setPadding(0, dp(6), 0, dp(18))
        })

        content.addView(label("CATATAN TERSIMPAN", 12f, 0xFFAAA6C3.toInt(), true).apply {
            setPadding(0, dp(4), 0, dp(8))
        })
        notesList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(notesList, matchWidthWrap())

        content.addView(action("＋  Catatan baru", primary = false) { startNewNote() }.apply {
            setPadding(dp(16), dp(13), dp(16), dp(13))
        }, matchWidthWrap().apply { topMargin = dp(10); bottomMargin = dp(18) })

        content.addView(label("JUDUL", 12f, 0xFFAAA6C3.toInt(), true).apply {
            setPadding(0, 0, 0, dp(7))
        })
        titleInput = editField("Judul catatan", singleLine = true)
        content.addView(titleInput, matchWidthWrap().apply { bottomMargin = dp(14) })

        content.addView(label("ISI CATATAN", 12f, 0xFFAAA6C3.toInt(), true).apply {
            setPadding(0, 0, 0, dp(7))
        })
        contentInput = editField("Mulai tulis catatan panjangmu di sini…", singleLine = false).apply {
            minLines = 10
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(15), dp(14), dp(15), dp(14))
        }
        content.addView(contentInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(260),
        ).apply { bottomMargin = dp(16) })

        content.addView(action("SIMPAN CATATAN", primary = true) { saveNote() }, matchWidthWrap())
        content.addView(action("TAMPILKAN DI WIDGET", primary = false) { setAsWidgetNote() },
            matchWidthWrap().apply { topMargin = dp(9) })
        content.addView(action("HAPUS CATATAN", primary = false, danger = true) { confirmDelete() },
            matchWidthWrap().apply { topMargin = dp(9) })

        selectedLabel = label("Widget menampilkan catatan yang dipilih.", 12f, 0xFF9292A2.toInt()).apply {
            setPadding(2, dp(16), 2, 0)
        }
        content.addView(selectedLabel, matchWidthWrap())
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
        ))
        setContentView(page)
    }

    private fun renderNotesList() {
        notesList.removeAllViews()
        val notes = NoteRepository.all(this)
        if (notes.isEmpty()) {
            notesList.addView(label("Belum ada catatan. Tekan ‘Catatan baru’ untuk mulai.", 14f, 0xFF9999A8.toInt()).apply {
                setPadding(dp(2), dp(8), dp(2), dp(8))
            })
        } else {
            val activeId = NoteRepository.active(this)?.id
            notes.forEach { note ->
                val summary = note.content.replace('\n', ' ').trim().take(72)
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(if (note.id == editingId) 0xFF29243B.toInt() else 0xFF20212A.toInt(), 15)
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        loadNote(note)
                        renderNotesList()
                    }
                }
                item.addView(label(note.title.ifBlank { "Catatan tanpa judul" }, 15f, Color.WHITE, true))
                if (summary.isNotBlank()) {
                    item.addView(label(summary, 12f, 0xFFB9B8C2.toInt()).apply {
                        maxLines = 2
                        setPadding(0, dp(4), 0, 0)
                    })
                }
                if (note.id == activeId) {
                    item.addView(label("DITAMPILKAN DI WIDGET", 10f, 0xFFC4A7FF.toInt(), true).apply {
                        setPadding(0, dp(7), 0, 0)
                    })
                }
                notesList.addView(item, matchWidthWrap().apply { bottomMargin = dp(7) })
            }
        }
    }

    private fun loadNote(note: Note) {
        editingId = note.id
        titleInput.setText(note.title)
        contentInput.setText(note.content)
        selectedLabel.text = if (NoteRepository.active(this)?.id == note.id) {
            "Catatan ini sedang ditampilkan di widget."
        } else {
            "Catatan ini belum dipilih untuk widget."
        }
    }

    private fun startNewNote() {
        editingId = null
        titleInput.setText("")
        contentInput.setText("")
        selectedLabel.text = "Catatan baru belum disimpan."
        titleInput.requestFocus()
        renderNotesList()
    }

    private fun saveNote() {
        val now = System.currentTimeMillis()
        val id = editingId ?: UUID.randomUUID().toString()
        val old = NoteRepository.find(this, id)
        val title = titleInput.text.toString().trim().ifBlank { "Catatan tanpa judul" }
        val note = Note(
            id = id,
            title = title,
            content = contentInput.text.toString(),
            createdAt = old?.createdAt ?: now,
            updatedAt = now,
        )
        NoteRepository.save(this, note)
        editingId = id
        if (NoteRepository.active(this) == null) NoteRepository.setActive(this, id)
        renderNotesList()
        updateWidget()
        selectedLabel.text = if (NoteRepository.active(this)?.id == id) {
            "Tersimpan dan sudah tampil di widget."
        } else {
            "Tersimpan. Tekan ‘Tampilkan di widget’ untuk memilihnya."
        }
        Toast.makeText(this, "Catatan tersimpan", Toast.LENGTH_SHORT).show()
    }

    private fun setAsWidgetNote() {
        val id = editingId
        if (id == null) {
            Toast.makeText(this, "Simpan catatan terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }
        NoteRepository.setActive(this, id)
        updateWidget()
        renderNotesList()
        selectedLabel.text = "Catatan ini sekarang tampil di widget layar utama."
        Toast.makeText(this, "Widget diperbarui", Toast.LENGTH_SHORT).show()
    }

    private fun confirmDelete() {
        val id = editingId
        if (id == null) {
            Toast.makeText(this, "Belum ada catatan yang dipilih", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Hapus catatan?")
            .setMessage("Catatan ini akan dihapus dari perangkat.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                NoteRepository.delete(this, id)
                editingId = null
                val next = NoteRepository.active(this)
                if (next != null) loadNote(next) else startNewNote()
                renderNotesList()
                updateWidget()
                Toast.makeText(this, "Catatan dihapus", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun updateWidget() = NoteWidgetProvider.refreshAll(this)

    private fun editField(hintText: String, singleLine: Boolean): EditText = EditText(this).apply {
        hint = hintText
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF777785.toInt())
        textSize = 16f
        background = getDrawable(R.drawable.bg_input)
        inputType = if (singleLine) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        isSingleLine = singleLine
        if (singleLine) setPadding(dp(15), dp(12), dp(15), dp(12))
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun action(
        text: String,
        primary: Boolean,
        danger: Boolean = false,
        onClick: () -> Unit,
    ) = TextView(this).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) Color.WHITE else if (danger) 0xFFFF9D9D.toInt() else 0xFFE2DDF2.toInt())
        background = rounded(
            when {
                primary -> 0xFF7054B5.toInt()
                danger -> 0xFF342126.toInt()
                else -> 0xFF292936.toInt()
            },
            14,
        )
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), 0xFF3B3949.toInt())
    }

    private fun matchWidthWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_NOTE_ID = "id.yoga.catatanutama.EXTRA_NOTE_ID"
    }
}
