package id.yoga.catatanutama.widget

import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import id.yoga.catatanutama.R
import id.yoga.catatanutama.data.NoteRepository

class NoteWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        NoteRowsFactory(applicationContext)
}

private class NoteRowsFactory(
    private val context: Context,
) : RemoteViewsService.RemoteViewsFactory {
    private var rows: List<String> = emptyList()

    override fun onCreate() = loadRows()
    override fun onDataSetChanged() = loadRows()
    override fun onDestroy() { rows = emptyList() }
    override fun getCount(): Int = rows.size
    override fun getViewAt(position: Int): RemoteViews? {
        if (position !in rows.indices) return null
        return RemoteViews(context.packageName, R.layout.widget_note_row).apply {
            setTextViewText(R.id.widget_row_text, rows[position])
        }
    }

    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1
    override fun getItemId(position: Int): Long = position.toLong()
    override fun hasStableIds(): Boolean = true

    private fun loadRows() {
        val note = NoteRepository.active(context)
        rows = note?.content?.let(::splitForScrolling).orEmpty()
    }

    /** Break very long paragraphs into smaller list rows so the home widget has real scroll stops. */
    private fun splitForScrolling(text: String): List<String> {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (normalized.isBlank()) return emptyList()

        val result = ArrayList<String>()
        val paragraphs = normalized.split(Regex("\\n[\\t ]*\\n+"))
        for (paragraph in paragraphs) {
            var remaining = paragraph.trim()
            while (remaining.length > 460) {
                var cut = remaining.lastIndexOfAny(charArrayOf(' ', '\n', '\t'), 460)
                if (cut < 220) cut = 460
                result += remaining.substring(0, cut).trim()
                remaining = remaining.substring(cut).trimStart()
            }
            if (remaining.isNotBlank()) result += remaining
        }
        return result
    }
}
