package id.yoga.catatanutama.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A small, private local store. Notes never leave this device. */
data class Note(
    val id: String,
    val title: String,
    val content: String,
    val createdAt: Long,
    val updatedAt: Long,
)

object NoteRepository {
    private const val FILE_NAME = "catatan-utama-notes.json"
    private const val PREFS_NAME = "catatan-utama-settings"
    private const val KEY_ACTIVE_NOTE = "active_note_id"
    private val lock = Any()

    fun all(context: Context): List<Note> = synchronized(lock) {
        readUnlocked(context).sortedByDescending { it.updatedAt }
    }

    fun find(context: Context, id: String): Note? = synchronized(lock) {
        readUnlocked(context).firstOrNull { it.id == id }
    }

    fun active(context: Context): Note? = synchronized(lock) {
        val notes = readUnlocked(context).sortedByDescending { it.updatedAt }
        val id = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_NOTE, null)
        notes.firstOrNull { it.id == id } ?: notes.firstOrNull()
    }

    fun setActive(context: Context, id: String?) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE_NOTE, id)
            .apply()
    }

    fun save(context: Context, note: Note) = synchronized(lock) {
        val notes = readUnlocked(context).toMutableList()
        val index = notes.indexOfFirst { it.id == note.id }
        if (index >= 0) notes[index] = note else notes.add(note)
        writeUnlocked(context, notes)
    }

    fun delete(context: Context, id: String) = synchronized(lock) {
        writeUnlocked(context, readUnlocked(context).filterNot { it.id == id })
        val activeId = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_NOTE, null)
        if (activeId == id) {
            val next = readUnlocked(context).maxByOrNull { it.updatedAt }
            setActive(context, next?.id)
        }
    }

    private fun readUnlocked(context: Context): List<Note> {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.isFile) return emptyList()
        return runCatching {
            val array = JSONArray(file.readText(Charsets.UTF_8))
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isBlank()) continue
                    add(
                        Note(
                            id = id,
                            title = item.optString("title", "Catatan tanpa judul"),
                            content = item.optString("content", ""),
                            createdAt = item.optLong("createdAt", 0L),
                            updatedAt = item.optLong("updatedAt", 0L),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun writeUnlocked(context: Context, notes: List<Note>) {
        val array = JSONArray()
        notes.forEach { note ->
            array.put(
                JSONObject()
                    .put("id", note.id)
                    .put("title", note.title)
                    .put("content", note.content)
                    .put("createdAt", note.createdAt)
                    .put("updatedAt", note.updatedAt),
            )
        }
        val target = File(context.filesDir, FILE_NAME)
        val temporary = File(context.filesDir, "$FILE_NAME.tmp")
        temporary.writeText(array.toString(), Charsets.UTF_8)
        if (!temporary.renameTo(target)) {
            target.writeText(array.toString(), Charsets.UTF_8)
            temporary.delete()
        }
    }
}
