package id.yoga.catatanutama.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import id.yoga.catatanutama.MainActivity
import id.yoga.catatanutama.R
import id.yoga.catatanutama.data.NoteRepository

class NoteWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        appWidgetIds.forEach { updateOne(context, appWidgetManager, it) }
    }

    companion object {
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, NoteWidgetProvider::class.java))
            if (ids.isEmpty()) return
            ids.forEach { updateOne(context, manager, it) }
            manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
            val note = NoteRepository.active(context)
            val views = RemoteViews(context.packageName, R.layout.widget_note)
            views.setTextViewText(
                R.id.widget_title,
                note?.title?.takeIf { it.isNotBlank() } ?: "Catatan Utama",
            )

            val serviceIntent = Intent(context, NoteWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                data = android.net.Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            views.setRemoteAdapter(R.id.widget_list, serviceIntent)
            views.setEmptyView(R.id.widget_list, R.id.widget_empty)

            val openIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                note?.let { putExtra(MainActivity.EXTRA_NOTE_ID, it.id) }
            }
            val openPendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId + 4100,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_header, openPendingIntent)
            manager.updateAppWidget(appWidgetId, views)
        }
    }
}
